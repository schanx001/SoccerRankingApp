using SoccerRanking;

namespace SoccerRankingTests
{
    [TestClass]
    public class SoccerRankingTests
    {
        [TestMethod]
        public void RankGames_TeamsWithDistinctPoints_VerifyOutput()
        {
            SoccerRankingGenerator s = new SoccerRankingGenerator();
            var currentDirectory = Directory.GetParent(Directory.GetCurrentDirectory())?.Parent?.Parent + "\\Resources";
            var inputFiles = Directory.GetFiles(currentDirectory + "\\input");
            var outputFiles = Directory.GetFiles(currentDirectory + "\\output");

            foreach (var file in inputFiles)
            {
                var outputFile = outputFiles.First(f => Path.GetFileName(f).Equals(Path.GetFileName(file)));
                if (File.Exists(file))
                {
                    List<string>? rankedTeams = s.Generate(file);
                    VerifySoccerTeamsRanking(rankedTeams, outputFile);
                }
            }
        }

        private void VerifySoccerTeamsRanking(List<string> teams, string outputFile)
        {
            Console.WriteLine("\n Expected Output");
            string[] outputLines = File.ReadAllLines(outputFile);
            Assert.IsTrue(outputLines.SequenceEqual(teams));

            foreach (var outputLine in outputLines)
            {
                Console.WriteLine(outputLine);
            }


            Console.WriteLine("\n =========== \n");
        }
    }
}