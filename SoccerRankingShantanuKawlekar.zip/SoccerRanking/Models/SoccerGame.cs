﻿namespace SoccerRanking.Models;

public class SoccerGame
{
    public Team Team1 { get; set; }

    public Team Team2 { get; set; }
}

public class Team
{
    public int Score { get; set; }
    public string Name { get; set; }
}