﻿namespace SoccerRanking.Models;

public class SoccerTeam
{
    private int _points;
    public string Name { get; set; }

    public int Wins { get; set; } = 0;

    public int Losses { get; set; } = 0;

    public int Draws { get; set; } = 0;

    public int Points { get; set; } = 0;
}