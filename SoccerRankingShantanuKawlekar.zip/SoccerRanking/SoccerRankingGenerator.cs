﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using SoccerRanking.Models;

namespace SoccerRanking;

public class SoccerRankingGenerator
{
    private static TextReader inputFile = Console.In;
    public static void Main(string[] args)
    {
        if (args.Length == 0)
        {
            // display usage
            return;
        }

        SoccerRankingGenerator generator = new SoccerRankingGenerator();
        _ = generator.Generate(args[0]);
    }

    public List<string> Generate(string filePath)
    {
        var soccerTeamsRanked = new List<string>();
        if (File.Exists(filePath))
        {
            inputFile = File.OpenText(filePath);
        }

        // parse the games from the text file
        var games = ParseGames(inputFile);

        // score the games and therefore the teams
        var scoredTeams = GetScoredTeams(games);

        // rank the teams based on the points and then alphabetically
        RankTeams(scoredTeams, soccerTeamsRanked);

        return soccerTeamsRanked;
    }

    private static void RankTeams(Dictionary<string, SoccerTeam> teams, List<string> soccerTeamsRanked)
    {
        var rankedTeams = teams.Values.OrderByDescending(t => t.Points)
            .ThenBy(t => t.Name).ToList();

        // ranking uses 1224 system
        int[] rankings = new int[rankedTeams.Count];
        rankings[0] = 0;
        int scorePrevTeam = -1;

        for (int i = 0; i < rankedTeams.Count; i++)
        {
            var team = rankedTeams[i];
            var points = (team.Wins * 3) + (team.Draws * 1);
            var pointUnit = points == 1 ? "pt" : "pts";

            // check if previous team in the order also has same points
            rankings[i] = scorePrevTeam == points ? rankings[i - 1] : i + 1;
            
            var rankInfo = $"{rankings[i]}. {team.Name}, {points} {pointUnit}";
            Console.WriteLine(rankInfo);
            scorePrevTeam = points;
            soccerTeamsRanked.Add(rankInfo);
        }
    }

    private static Dictionary<string, SoccerTeam> GetScoredTeams(List<SoccerGame> games)
    {
        var scoredTeams = new Dictionary<string, SoccerTeam>();

        if (games == null)
        {
            return null;
        }

        foreach (var soccerGame in games)
        {
            ScoreGame(soccerGame, scoredTeams);
        }

        return scoredTeams;
    }

    private static void ScoreGame(SoccerGame game, Dictionary<string, SoccerTeam> scoredTeams)
    {
        if (game.Team1.Score > game.Team2.Score)
        {
            ScoreTeam(game.Team1, scoredTeams, 1);
            ScoreTeam(game.Team2, scoredTeams, 0, 1);
        }
        else if (game.Team1.Score < game.Team2.Score)
        {
            ScoreTeam(game.Team2, scoredTeams, 1);
            ScoreTeam(game.Team1, scoredTeams, 0, 1);
        }
        else
        {
            ScoreTeam(game.Team1, scoredTeams, draws:1);
            ScoreTeam(game.Team2, scoredTeams, draws:1);
        }
    }

    private static void ScoreTeam(Team team, Dictionary<string, SoccerTeam> scoredTeams, int wins = 0, int losses = 0, int draws = 0)
    {
        if (scoredTeams.TryGetValue(team.Name, out var soccerTeam))
        {
            soccerTeam.Wins += wins;
            soccerTeam.Losses += losses;
            soccerTeam.Draws += draws;
            soccerTeam.Points += (wins * 3) + (draws * 1);
        }
        else
        {
            scoredTeams[team.Name] = new SoccerTeam
            {
                Name = team.Name,
                Wins = wins,
                Losses = losses,
                Draws = draws,
                Points = (wins * 3) + (draws * 1)
            };
        }
    }

    private static List<SoccerGame> ParseGames(TextReader input)
    {
        var games = new List<SoccerGame>();
        for (string line; (line = input.ReadLine()) != null;)
        {
            var teamScore = line.Split(',');
            games.Add(GetSoccerGame(teamScore));
        }

        return games;
    }

    private static SoccerGame GetSoccerGame(string[] teamScore)
    {
        var team1 = teamScore[0].Trim().Split(" ");
        var lastIndexSpace = teamScore[1].Trim().LastIndexOf(" ", StringComparison.Ordinal);

        return new SoccerGame()
        {
            Team1 = new Team()
            {
                Name = team1[0],
                Score = Convert.ToInt32(team1[1])
            },
            Team2 = new Team()
            {
                Name = teamScore[1].Trim()[..lastIndexSpace],
                Score = Convert.ToInt32(teamScore[1][(lastIndexSpace + 1)..])
            }
        };
    }
}